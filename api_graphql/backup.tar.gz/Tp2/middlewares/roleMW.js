const jwt = require('jsonwebtoken');
const User = require('../models/User');

const adminMiddleware = async (req, res, next) => {
    const token = req.header('Authorization');
    if (!token) {
        return res.status(401).json({ message: 'Authentification refusée' });
    }

    try {
        const decoded = jwt.verify(token, process.env.JWT_SECRET);
        const user = await User.findByPk(decoded.id);
        if (!user) {
            return res.status(401).json({ message: 'Authentification refusée' });
        }
        if (user.role !== 'admin') {
            return res.status(403).json({ message: 'Accès refusé' });
        }
        req.user = user;
        next();
    } catch (error) {
        res.status(401).json({ message: 'Authentification refusée' });
    }
}

const restaurateurMiddleware = async (req, res, next) => {
    const token = req.header('Authorization');
    if (!token) {
        return res.status(401).json({ message: 'Authentification refusée' });
    }

    try {
        const decoded = jwt.verify(token, process.env.JWT_SECRET);
        const user = await User.findByPk(decoded.id);
        if (!user) {
            return res.status(401).json({ message: 'Authentification refusée' });
        }
        if (user.role !== 'restaurateur') {
            return res.status(403).json({ message: 'vous netes pas un restaurateur' });
        }
        req.user = user;
        next();
    } catch (error) {
        res.status(401).json({ message: 'Authentification refusée' });
    }
}

const userMiddleware = async (req, res, next) => {
    const token = req.header('Authorization');
    if (!token) {
        return res.status(401).json({ message: 'Authentification refusée' });
    }

    try {
        const decoded = jwt.verify(token, process.env.JWT_SECRET);
        const user = await User.findByPk(decoded.id);
        if (!user) {
            return res.status(401).json({ message: 'Authentification refusée' });
        }
        if (user.role !== 'user') {
            return res.status(403).json({ message: 'vous netes pas un restaurateur' });
        }
        req.user = user;
        next();
    } catch (error) {
        res.status(401).json({ message: 'Authentification refusée' });
    }
}

module.exports = {
    adminMiddleware,
    restaurateurMiddleware
};