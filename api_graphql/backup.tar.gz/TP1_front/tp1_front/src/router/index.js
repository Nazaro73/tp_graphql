import { createRouter, createWebHistory } from 'vue-router'
import Login from '../views/Login.vue'
import adminHome from '@/views/adminHome.vue'
import userHome from '@/views/userHome.vue'
import restaurateur from '@/views/restaurateur.vue'
import RestaurantDetails from '@/components/RestaurantDetails.vue'



const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: '/login',
      name: 'login',
      component: Login
    },
    {
      path: '/user',
      name: 'userHome',
      component: userHome
    },
    {
      path: '/admin',
      name: 'adminHome',
      component: adminHome
    },
    {
      path: '/restaurateur',
      name: 'restaurateur',
      component: restaurateur
    },
    { path: '/restaurant/:id', 
      name: 'RestaurantDetails', 
      component: RestaurantDetails, 
      props: true }
    
  ]
})

export default router
