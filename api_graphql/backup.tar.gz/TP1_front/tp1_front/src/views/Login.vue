<script setup>
import { ref } from 'vue';
import axios from 'axios';
import { useRouter } from 'vue-router';

const email = ref('');
const password = ref('');
const message = ref('');
const router = useRouter();

const login = async () => {
  try {
    const response = await axios.post('http://localhost:3000/users/login', {
      email: email.value,
      password: password.value
    });
    const token = response.data.token;
    localStorage.setItem('token', token);

    const meResponse = await axios.get('http://localhost:3000/users/me', {
      headers: { Authorization: `Bearer ${token}` }
    });

    const role = meResponse.data.role;
    if (role === 'admin') {
      router.push('/admin');
    } else if (role === 'user') {
      router.push('/user');
    } else if (role === 'restaurateur') {
      router.push('/restaurateur');
    }
  } catch (error) {
    message.value = 'Login failed: ' + error.response.data.message;
  }
};
</script>

<template>
  <div>
    <h1>Login</h1>
    <form @submit.prevent="login">
      <div>
        <label for="email">Email:</label>
        <input type="email" id="email" v-model="email" required />
      </div>
      <div>
        <label for="password">Password:</label>
        <input type="password" id="password" v-model="password" required />
      </div>
      <button type="submit">Login</button>
    </form>
    <p>{{ message }}</p>
  </div>
</template>