<template>
  <div class="home-view">
    <!-- Affiche la liste des restaurants avec la barre de recherche -->
    <RestaurantList />
  </div>
  <Panier />
  
</template>

<script>
import RestaurantList from "../components/Restaurant.vue";
import Panier from "@/components/Panier.vue";
export default {
  name: 'HomeView',
  components: {
    RestaurantList,
    Panier
  }
};
</script>

<style scoped>
.home-view {
  display: flex;
  justify-content: center;
  align-items: center;
  padding: 20px;
}
</style>
