<template>
  <div class="restaurant-list">
    <!-- Barre de recherche -->
    <div class="search-bar">
      <input
        type="text"
        v-model="searchQuery"
        placeholder="Rechercher des restaurants"
      />
    </div>

    <!-- Titre -->
    <h2 class="title">Nos Restaurants :</h2>

    <!-- Liste des restaurants avec scroll horizontal -->
    <div class="restaurants-container">
      <div 
        class="restaurant-card" 
        v-for="restaurant in filteredRestaurants" 
        :key="restaurant.id"
        @click="goToRestaurantDetails(restaurant.id)"
      >
        <img :src="restaurant.image" :alt="restaurant.nom" class="restaurant-image" />
        <p class="restaurant-name">{{ restaurant.nom }}</p>
      </div>
    </div>
  </div>
</template>

<script>
import { ref, computed, onMounted } from 'vue';
import axios from 'axios';
import { useRouter } from 'vue-router';

export default {
  name: 'RestaurantList',
  setup() {
    const searchQuery = ref('');
    const restaurants = ref([]);
    const router = useRouter();

    onMounted(async () => {
      try {
        const response = await axios.get('http://localhost:3000/restaurants');
        restaurants.value = response.data;
      } catch (error) {
        console.error('Erreur lors de la récupération des restaurants:', error);
      }
    });

    const filteredRestaurants = computed(() => {
      return restaurants.value.filter(restaurant =>
        restaurant.nom.toLowerCase().includes(searchQuery.value.toLowerCase())
      );
    });

    function goToRestaurantDetails(id) {
      router.push({ name: 'RestaurantDetails', params: { id } });
    }

    return {
      searchQuery,
      filteredRestaurants,
      goToRestaurantDetails
    };
  }
};
</script>

  
  <style scoped>
  .restaurant-list {
    padding: 20px;
    text-align: center;
  }
  
  .search-bar {
    margin-bottom: 20px;
  }
  
  .search-bar input {
    width: 50%;
    padding: 10px;
    border-radius: 20px;
    border: 1px solid #ccc;
    font-size: 16px;
    text-align: center;
  }
  
  .title {
    font-size: 24px;
    margin-bottom: 20px;
  }
  
  .restaurants-container {
    display: flex;
    overflow-x: auto;
    padding-bottom: 20px;
  }
  
  .restaurant-card {
    flex: 0 0 auto;
    margin-right: 20px;
    text-align: center;
    width: 200px;
  }
  
  .restaurant-image {
    width: 100%;
    height: 150px;
    object-fit: cover;
    border-radius: 10px;
    margin-bottom: 10px;
  }
  
  .restaurant-name {
    font-size: 18px;
    font-weight: bold;
  }
  </style>
  