<template>
  <div>
    <h2>Mon Panier</h2>

    <!-- Affiche les articles du panier -->
    <div v-if="items.length">
      <ul>
        <li v-for="item in items" :key="item.id">
          <!-- Affiche l'image du plat -->
          <img :src="item.plat.image" alt="Image du plat" class="plat-image" />

          <span>{{ item.plat.nom }} - {{ item.quantity }} x {{ item.plat.prix }} €</span>
          <button @click="removeFromCart(item.id)">Supprimer</button>
          <button @click="updateQuantity(item.id, item.quantity + 1)">+</button>
          <button @click="updateQuantity(item.id, item.quantity - 1)" :disabled="item.quantity <= 1">-</button>
        </li>
      </ul>
      <p><strong>Total:</strong> {{ calculateTotal() }} €</p>
      <button @click="validateCart">Valider le Panier</button>
    </div>
    <p v-else>Votre panier est vide.</p>
  </div>
</template>

<script>
import axios from 'axios';

export default {
  data() {
    return {
      items: []
    };
  },
  async created() {
    await this.fetchCartItems();
  },
  methods: {
    async fetchCartItems() {
      try {
        const response = await axios.get(`/api/panier/user/${this.userId}`);
        this.items = response.data; // Récupère directement les articles du panier
      } catch (error) {
        console.error("Erreur lors de la récupération des articles du panier:", error);
      }
    },
    async removeFromCart(itemId) {
      try {
        await axios.delete(`/api/panier/remove/${itemId}`);
        await this.fetchCartItems();
      } catch (error) {
        console.error("Erreur lors de la suppression de l'article du panier:", error);
      }
    },
    async updateQuantity(itemId, quantity) {
      try {
        if (quantity <= 0) {
          await this.removeFromCart(itemId);
          return;
        }
        await axios.put(`/api/panier/update/${itemId}`, { quantity });
        await this.fetchCartItems();
      } catch (error) {
        console.error("Erreur lors de la mise à jour de la quantité:", error);
      }
    },
    async validateCart() {
      try {
        // Valider le panier et créer une commande
        const response = await axios.post(`/api/orders/create`, {
          userId: this.userId,
          plats: this.items.map((item) => ({
            id: item.platId,
            quantity: item.quantity
          }))
        });
        alert(response.data.message);
        this.items = []; // Vider le panier après validation
      } catch (error) {
        console.error("Erreur lors de la validation du panier:", error);
      }
    },
    calculateTotal() {
      return this.items.reduce((total, item) => total + item.plat.prix * item.quantity, 0);
    }
  },
  computed: {
    userId() {
      return this.$store.state.userId; // Remplacer par l'ID utilisateur actuel
    }
  }
};
</script>

<style scoped>
.plat-image {
  width: 80px;
  height: 80px;
  object-fit: cover;
  margin-right: 10px;
  border-radius: 5px;
}
</style>
