<template>
    <div>
      <h2>Mes Commandes</h2>
  
      <div v-if="orders.length">
        <div v-for="order in orders" :key="order.id" class="order">
          <h3>Commande #{{ order.id }} - Statut: {{ order.status }}</h3>
          <ul>
            <li v-for="item in order.paniers" :key="item.id">
              <!-- Affiche l'image du plat -->
              <img :src="item.plat.image" alt="Image du plat" class="plat-image" />
  
              {{ item.plat.nom }} - Quantité: {{ item.quantity }}
            </li>
          </ul>
          <p><strong>Total :</strong> {{ calculateOrderTotal(order) }} €</p>
        </div>
      </div>
      <p v-else>Vous n'avez pas encore de commande.</p>
    </div>
  </template>
  
  <script>
  import axios from 'axios';
  
  export default {
    data() {
      return {
        orders: []
      };
    },
    async created() {
      await this.fetchOrders();
    },
    methods: {
      async fetchOrders() {
        try {
          const response = await axios.get(`/api/orders/user/${this.userId}`);
          this.orders = response.data;
        } catch (error) {
          console.error("Erreur lors de la récupération des commandes:", error);
        }
      },
      calculateOrderTotal(order) {
        return order.paniers.reduce((total, item) => total + item.plat.prix * item.quantity, 0);
      }
    },
    computed: {
      userId() {
        return this.$store.state.userId; // Remplacer par l'ID utilisateur actuel
      }
    }
  };
  </script>
  
  <style scoped>
  .plat-image {
    width: 60px;
    height: 60px;
    object-fit: cover;
    margin-right: 10px;
    border-radius: 5px;
  }
  </style>
  