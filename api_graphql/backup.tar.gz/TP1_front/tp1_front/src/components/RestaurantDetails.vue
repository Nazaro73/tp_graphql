<template>
  <div class="restaurant-details">
    <h2>{{ restaurant.nom }}</h2>
    <img :src="restaurant.image" :alt="restaurant.nom" class="restaurant-image" />

    <h3>Plats disponibles :</h3>
    <div class="plats-container">
      <div class="plat-card" v-for="plat in plats" :key="plat.id">
        <img :src="plat.image" :alt="plat.nom" class="plat-image" />
        <div class="plat-info">
          <h4 class="plat-name">{{ plat.nom }}</h4>
          <p class="plat-description">{{ plat.description }}</p>
          <p class="plat-price">{{ plat.prix.toFixed(2) }} €</p>
          <button @click="addToCart(plat)" class="add-to-cart">Ajouter au Panier</button>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { ref, onMounted } from 'vue';
import axios from 'axios';
import { useRoute } from 'vue-router';

export default {
  name: 'RestaurantDetails',
  setup() {
    const route = useRoute();
    const restaurant = ref({});
    const plats = ref([]);

    // Récupération des données du restaurant et des plats
    const fetchDetails = async () => {
      try {
        // Récupérer les détails du restaurant
        const restaurantResponse = await axios.get(`http://localhost:3000/restaurants/${route.params.id}`);
        restaurant.value = restaurantResponse.data;

        // Récupérer les plats disponibles dans ce restaurant
        const platsResponse = await axios.get(`http://localhost:3000/plats/restaurant/${route.params.id}`);
        plats.value = platsResponse.data;
      } catch (error) {
        console.error('Erreur lors de la récupération des données:', error);
      }
    };

    // Ajouter un plat au panier
    const addToCart = async (plat) => {
      try {
        await axios.post('http://localhost:3000/panier/add', {
          platId: plat.id,
          quantity: 1, // Quantité initiale
          userId: 7, // Remplacez par l'ID de l'utilisateur actuel si nécessaire
        });
        alert(`${plat.nom} a été ajouté au panier.`);
      } catch (error) {
        console.error('Erreur lors de l\'ajout au panier:', error);
      }
    };

    onMounted(fetchDetails);

    return { restaurant, plats, addToCart };
  },
};
</script>

<style scoped>
.restaurant-details {
  text-align: center;
  padding: 20px;
}

.restaurant-image {
  width: 100%;
  max-width: 400px;
  height: auto;
  border-radius: 10px;
  margin: 20px 0;
}

.plats-container {
  display: flex;
  flex-wrap: wrap;
  gap: 20px;
  justify-content: center;
  margin-top: 20px;
}

.plat-card {
  width: 250px;
  border: 1px solid #ccc;
  border-radius: 10px;
  overflow: hidden;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
  text-align: left;
}

.plat-image {
  width: 100%;
  height: 150px;
  object-fit: cover;
}

.plat-info {
  padding: 15px;
}

.plat-name {
  font-size: 18px;
  font-weight: bold;
  margin-bottom: 5px;
}

.plat-description {
  font-size: 14px;
  color: #666;
  margin-bottom: 10px;
}

.plat-price {
  font-size: 16px;
  font-weight: bold;
  color: #333;
  margin-bottom: 10px;
}

.add-to-cart {
  background-color: #4CAF50;
  color: white;
  border: none;
  padding: 10px 15px;
  border-radius: 5px;
  cursor: pointer;
  font-size: 14px;
}

.add-to-cart:hover {
  background-color: #45a049;
}
</style>
