<template>
  <h1>Voici la page Admin </h1>
</template>

<style>

</style>
